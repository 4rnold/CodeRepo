package com.lagou.rabbitmq.demo.demo_15_springboot_consumer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Demo15SpringbootConsumerApplication {

    public static void main(String[] args) {
        SpringApplication.run(Demo15SpringbootConsumerApplication.class, args);
    }

}

package com.lagou.demo_17_ttl_springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Demo17TtlSpringbootApplication {

    public static void main(String[] args) {
        SpringApplication.run(Demo17TtlSpringbootApplication.class, args);
    }

}

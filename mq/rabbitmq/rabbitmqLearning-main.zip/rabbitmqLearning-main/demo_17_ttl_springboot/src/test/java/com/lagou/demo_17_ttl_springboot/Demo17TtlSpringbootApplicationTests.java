package com.lagou.demo_17_ttl_springboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Demo17TtlSpringbootApplicationTests {

    @Test
    void contextLoads() {
    }

}

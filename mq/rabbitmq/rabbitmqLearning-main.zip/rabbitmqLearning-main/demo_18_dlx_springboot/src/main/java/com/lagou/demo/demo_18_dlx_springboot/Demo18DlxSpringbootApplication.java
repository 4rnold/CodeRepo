package com.lagou.demo.demo_18_dlx_springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Demo18DlxSpringbootApplication {

	public static void main(String[] args) {
		SpringApplication.run(Demo18DlxSpringbootApplication.class, args);
	}

}

package com.lagou.demo.demo_18_dlx_springboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Demo18DlxSpringbootApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com_lagou_demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Demo20PublisherconfirmsSpringboot02Application {

    public static void main(String[] args) {
        SpringApplication.run(Demo20PublisherconfirmsSpringboot02Application.class, args);
    }

}

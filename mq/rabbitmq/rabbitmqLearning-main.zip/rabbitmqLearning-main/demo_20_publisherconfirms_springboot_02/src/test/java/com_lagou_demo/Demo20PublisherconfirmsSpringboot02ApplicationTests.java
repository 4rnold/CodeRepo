package com_lagou_demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Demo20PublisherconfirmsSpringboot02ApplicationTests {

    @Test
    void contextLoads() {
    }

}

package com.lagou.rabbit.demo_22_springboot_consumerack;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Demo22SpringbootConsumerAckApplicationTests {

	@Test
	void contextLoads() {
	}

}

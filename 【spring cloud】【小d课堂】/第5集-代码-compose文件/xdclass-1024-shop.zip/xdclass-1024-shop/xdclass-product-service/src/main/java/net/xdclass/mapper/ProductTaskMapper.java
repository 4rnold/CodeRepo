package net.xdclass.mapper;

import net.xdclass.model.ProductTaskDO;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author 二当家小D
 * @since 2021-02-25
 */
public interface ProductTaskMapper extends BaseMapper<ProductTaskDO> {


}

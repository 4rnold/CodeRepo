package net.xdclass.service;

import net.xdclass.vo.BannerVO;

import java.util.List;

public interface BannerService {

    List<BannerVO> list();


}
